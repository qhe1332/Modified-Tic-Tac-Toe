function getRandomInteger(lower, upper)
{
	if(lower >= upper)
	{
		return null;
	}
	var multiplier = upper-(lower - 1);
	var rnd = parseInt(Math.random()* multiplier);
	rnd += lower;
	
	return rnd;
}

function clearBoard(space)
{
	for(var i = 0; i < space.childNodes.length +1; i++)
	{
		space.removeChild(space.childNodes[0]);                   //why?
		if(space.hasChildNodes() == true)
		{
			space.removeChild(space.childNodes[0]);
		}
		if(space.hasChildNodes() == true)
		{
			space.removeChild(space.childNodes[0]);
		}
	}
}


function comp(pass)                                              //Select Computer's move by random
{
	if(WON == true)
	{
		return;
	}
	if(pass != 0)
	{
		var box = document.getElementById(pass);
		spot = pass;
		next = 0;
	}
	else
	{
		spot = getRandomInteger(1, board * board);
		spot = spot.toString();
		var box = document.getElementById(spot);
		if(compIn.length + useIn.length == 9)
		{
			return;
		}
	}
	while(box.hasChildNodes() == true)
	{
		spot = getRandomInteger(1, board * board);
		spot = spot.toString();
		box = document.getElementById(spot);
	}
	var input = document.createElement("img");
	input.src = "X.png";
	if(board == 3)
	{
		input.style.width = "100px";
	}
	if(board == 4)
	{
		input.style.width = "75px";
	}
	if(board == 5)
	{
		input.style.width = "50px";
	}
	box.appendChild(input);
	compIn.push(spot);
	
	if(board == 3)
	{
		evaluateComp(combo3);
	}
	if(board == 4)
	{
		evaluateComp(combo4);
	}
	if(board == 5)
	{
		evaluateComp(combo5);
	}
}

function evaluate(combo)                                 //evaluate after every move whether the player won the game
{
	var displayText = document.getElementById("al");
	if(compIn.length + useIn.length == 9)
	{
		displayText.innerHTML = "Draw. Your have " + enemy + " enemy(ies) left.";
		manageProcedure();
	}
	for(var i = 0; i < combo.length; i++)
	{
		for(var a = 0; a < combo[i].length; a++)
		{
			if(useIn.indexOf(combo[i][a]) != -1)
			{
				status ++;
			}
			if(status == board)
			{
				enemy --;
				WON = true;
				manageProcedure();
				return;
			}
		}
		if(status == board - 1)                    //ai
		{
			
		}
		if(status < board)
		{
			status = 0;
		}
	}
	if(selected.indexOf("object2") != -1)
	{
		var random = getRandomInteger(1, 10);
		if(random == 1)
		{
			displayText.innerHTML = "Crowned Kitten has activated her power. You can replace an X with a O in your next move.";
			replace = ALLOW;
		}
	}
	
}
			
function evaluateComp(combo)                           //evaluate after every move whether the computer won the game
{
	if(compIn.length + useIn.length == board * board)
	{
		manageProcedure();
	}
	for(var i = 0; i < combo.length; i++)
	{
		for(var a = 0; a < combo[i].length; a++)
		{
			if(compIn.indexOf(combo[i][a]) != -1)
			{
				compStat ++;
			}
			if(compStat == board)
			{
				document.getElementById("al").innerHTML = "You Lose";
				compStat = 0;
				if(selected.indexOf("object5") == -1)
				{
					board = 3;
					ROUND = 1;
				}
				else
				{
					var num = selected.indexOf("object5");
					selected.splice(num,1);
				}
				manageProcedure();
				return;
			}
		}
		if(compStat < board)
		{
			compStat = 0;
		}
	}
	if(selected.indexOf("object3") != -1)         //dog cop skill
	{
		var random = getRandomInteger(1, 10);
		if(random == 1)
		{
			next = getRandomInteger(1, (board * board));
			while(useIn.indexOf(next) != -1 && compIn.indexOf(next) != -1)
			{
				alert(compIn.indexOf(next));
				next = getRandomInteger(1, board * board);
			}
			document.getElementById("al").innerHTML = "Dog Cop has activated his skill. Your enemy's next move is at box" + next + ".";
		}
	}
}

function buildBoard()                                                //build up each game board
{
	var chipCount = document.createElement("div");
	chipCount.innerHTML = "Chip = " + CHIP;
	var boxNum = board * board;
	var bbox = document.getElementById("board");
	for(var i = 1; i < board + 1; i++)
	{
		var row = document.createElement("tr");
		for(var a = 1; a < board + 1; a++)
		{
			var box = document.createElement("td");
			box.id = ((i-1)*board + a);
			box.style.width = 100/board + "%";
			box.style.height = 100/board + "%";
			row.appendChild(box);
		}
		bbox.appendChild(row);
	}
	
	document.getElementById("1").addEventListener("click", function(){ click("1"); });
	document.getElementById("2").addEventListener("click", function(){ click("2"); });
	document.getElementById("3").addEventListener("click", function(){ click("3"); });
	document.getElementById("4").addEventListener("click", function(){ click("4"); });
	document.getElementById("5").addEventListener("click", function(){ click("5"); });
	document.getElementById("6").addEventListener("click", function(){ click("6"); });
	document.getElementById("7").addEventListener("click", function(){ click("7"); });
	document.getElementById("8").addEventListener("click", function(){ click("8"); });
	document.getElementById("9").addEventListener("click", function(){ click("9"); });
	if(board == 4 || board == 5)
	{
		document.getElementById("10").addEventListener("click", function(){ click("10"); });
		document.getElementById("11").addEventListener("click", function(){ click("11"); });
		document.getElementById("12").addEventListener("click", function(){ click("12"); });
		document.getElementById("13").addEventListener("click", function(){ click("13"); });
		document.getElementById("14").addEventListener("click", function(){ click("14"); });
		document.getElementById("15").addEventListener("click", function(){ click("15"); });
		document.getElementById("16").addEventListener("click", function(){ click("16"); });
	}
	if(board == 5)
	{
		document.getElementById("17").addEventListener("click", function(){ click("17"); });
		document.getElementById("18").addEventListener("click", function(){ click("18"); });
		document.getElementById("19").addEventListener("click", function(){ click("19"); });
		document.getElementById("20").addEventListener("click", function(){ click("20"); });
		document.getElementById("21").addEventListener("click", function(){ click("21"); });
		document.getElementById("22").addEventListener("click", function(){ click("22"); });
		document.getElementById("23").addEventListener("click", function(){ click("23"); });
		document.getElementById("24").addEventListener("click", function(){ click("24"); });
		document.getElementById("25").addEventListener("click", function(){ click("25"); });
	}
}

function click(num)                                                //actions taken after the players click a box
{
	var displayText = document.getElementById("al");
	var box = document.getElementById(num);
	if(box.hasChildNodes() == true)
	{
		if(replace == ALLOW)
		{
			replace = NO;
			box.removeChild(box.lastChild);
			document.getElementById("al").innerHTML = "";
		}	
		else
		{
			return;
		}
	}
	var input = document.createElement("img");
	input.src = "circle.png";
	if(board == 3)
	{
		input.style.width = "100px";
	}
	if(board == 4)
	{
		input.style.width = "75px";
	}
	if(board == 5)
	{
		input.style.width = "50px";
	}
	box.appendChild(input);
	useIn.push(num);
	if(board == 3)
	{
		evaluate(combo3);
	}
	if(board == 4)
	{
		evaluate(combo4);
	}
	if(board == 5)
	{
		evaluate(combo5);
	}
	if(selected.indexOf("object1") != -1)         //rabbit warrior skill
	{
		var random = getRandomInteger(1, 10);
		if(random == 1)
		{
			displayText.innerHTML = "Rabbit Warrior has activated her skill. Your enemy's turn was skipped once.";
			return;
		}
	}
	if(skip == true)
	{
		displayText.innerHTML = "You used Skippy Spell to skip your enemies' turn by one";
		skip = false;
		return;
	}
	displayText.innerHTML = "";
	comp(next);	
}